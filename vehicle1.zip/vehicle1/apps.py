from django.apps import AppConfig


class VehicleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vehicle1'
